from django.shortcuts import render
from .models import Course

def course_list(request):
    courses = Course.object.all()
    return render(request, 'index.html', {'courses': courses})
